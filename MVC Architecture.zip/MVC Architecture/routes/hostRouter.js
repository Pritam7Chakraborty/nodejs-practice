const express = require("express");
const hostRouter = express.Router();

const homescontroller = require("../controller/homes");

hostRouter.get("/add-home", homescontroller.getAddHome);

hostRouter.post("/add-home", homescontroller.postAddHome);

exports.hostRouter = hostRouter;
