const express = require("express");
const userRouter = express.Router();
const homescontroller = require("../controller/homes");


userRouter.get("/",homescontroller.getHomes);

module.exports = userRouter;
